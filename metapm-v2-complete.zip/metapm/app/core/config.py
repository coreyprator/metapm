"""
MetaPM Configuration
Environment-based settings management

Note: Sensitive values (passwords, API keys) come from Google Secret Manager,
not from .env files. See app/core/secrets.py
"""

import os
from typing import List, Optional
from pydantic_settings import BaseSettings
from functools import cached_property


class Settings(BaseSettings):
    """
    Application settings.
    
    Non-sensitive values: Loaded from environment variables
    Sensitive values: Loaded from Google Secret Manager via secrets.py
    """
    
    # Database (non-sensitive parts)
    DB_SERVER: str = "localhost"
    DB_NAME: str = "MetaPM"
    DB_USER: str = "metapm_user"
    DB_DRIVER: str = "ODBC Driver 18 for SQL Server"
    
    # DB_PASSWORD comes from Secret Manager, accessed via property below
    
    # GCP
    GCP_PROJECT_ID: str = "metapm"
    CLOUD_SQL_INSTANCE: str = ""
    
    # GCS
    GCS_MEDIA_BUCKET: str = "metapm-media"
    
    # Application
    ENVIRONMENT: str = "development"
    LOG_LEVEL: str = "INFO"
    
    # CORS - allow all origins in dev, restrict in production
    CORS_ORIGINS: List[str] = ["*"]
    
    # API keys come from Secret Manager, not here
    # Access via: from app.core.secrets import get_openai_api_key
    
    @cached_property
    def DB_PASSWORD(self) -> str:
        """Get database password from Secret Manager."""
        from app.core.secrets import get_db_password
        return get_db_password()
    
    @cached_property
    def OPENAI_API_KEY(self) -> str:
        """Get OpenAI API key from Secret Manager."""
        from app.core.secrets import get_openai_api_key
        return get_openai_api_key()
    
    @cached_property
    def ANTHROPIC_API_KEY(self) -> str:
        """Get Anthropic API key from Secret Manager."""
        from app.core.secrets import get_anthropic_api_key
        return get_anthropic_api_key()
    
    @property
    def database_url(self) -> str:
        """Build pyodbc connection string"""
        # For Cloud Run with Cloud SQL proxy
        if self.DB_SERVER.startswith("/cloudsql/"):
            return (
                f"DRIVER={{{self.DB_DRIVER}}};"
                f"SERVER={self.DB_SERVER};"
                f"DATABASE={self.DB_NAME};"
                f"UID={self.DB_USER};"
                f"PWD={self.DB_PASSWORD};"
                "TrustServerCertificate=yes;"
            )
        # For local development or direct IP connection
        return (
            f"DRIVER={{{self.DB_DRIVER}}};"
            f"SERVER={self.DB_SERVER};"
            f"DATABASE={self.DB_NAME};"
            f"UID={self.DB_USER};"
            f"PWD={self.DB_PASSWORD};"
            "TrustServerCertificate=yes;"
        )
    
    class Config:
        # Only load non-sensitive values from .env
        env_file = ".env"
        env_file_encoding = "utf-8"


# Global settings instance
settings = Settings()
