"""
MetaPM Secrets Management
Retrieve secrets from Google Secret Manager (NOT .env files)

Per methodology LL-019: All credentials must come from Secret Manager.
"""

import os
import logging
from functools import lru_cache
from typing import Optional

logger = logging.getLogger(__name__)

# Check if we're running in Cloud Run (secrets mounted as env vars)
# or locally (need to call Secret Manager API)
IS_CLOUD_RUN = os.getenv("K_SERVICE") is not None


def get_secret(secret_id: str, project_id: Optional[str] = None) -> str:
    """
    Retrieve a secret value.
    
    In Cloud Run: Secrets are mounted as environment variables via --set-secrets
    Locally: Falls back to environment variable or calls Secret Manager API
    
    Args:
        secret_id: The secret name (e.g., 'openai-api-key')
        project_id: GCP project ID (defaults to GCP_PROJECT_ID env var)
    
    Returns:
        The secret value as a string
    
    Raises:
        ValueError: If secret cannot be retrieved
    """
    # Convert secret name to env var format (e.g., 'openai-api-key' -> 'OPENAI_API_KEY')
    env_var_name = secret_id.upper().replace("-", "_")
    
    # First, check if it's already in environment (Cloud Run mounts secrets as env vars)
    env_value = os.getenv(env_var_name)
    if env_value:
        logger.debug(f"Secret '{secret_id}' loaded from environment variable")
        return env_value
    
    # If running locally, try to call Secret Manager API
    if not IS_CLOUD_RUN:
        return _get_secret_from_api(secret_id, project_id)
    
    raise ValueError(f"Secret '{secret_id}' not found in environment. "
                     f"Ensure --set-secrets includes {env_var_name}={secret_id}:latest")


def _get_secret_from_api(secret_id: str, project_id: Optional[str] = None) -> str:
    """
    Retrieve secret directly from Secret Manager API.
    Used for local development when secrets aren't mounted as env vars.
    """
    try:
        from google.cloud import secretmanager
    except ImportError:
        raise ValueError(
            f"Secret '{secret_id}' not in environment and google-cloud-secret-manager "
            "not installed. Run: pip install google-cloud-secret-manager"
        )
    
    project_id = project_id or os.getenv("GCP_PROJECT_ID", "metapm")
    
    try:
        client = secretmanager.SecretManagerServiceClient()
        name = f"projects/{project_id}/secrets/{secret_id}/versions/latest"
        
        response = client.access_secret_version(request={"name": name})
        secret_value = response.payload.data.decode("UTF-8")
        
        logger.debug(f"Secret '{secret_id}' loaded from Secret Manager API")
        return secret_value
        
    except Exception as e:
        logger.error(f"Failed to retrieve secret '{secret_id}': {e}")
        raise ValueError(f"Could not retrieve secret '{secret_id}' from Secret Manager: {e}")


@lru_cache(maxsize=10)
def get_cached_secret(secret_id: str) -> str:
    """
    Get a secret with caching to avoid repeated API calls.
    Use for frequently accessed secrets.
    """
    return get_secret(secret_id)


# Convenience functions for specific secrets
def get_db_password() -> str:
    """Get database password."""
    return get_secret("metapm-db-password")


def get_openai_api_key() -> str:
    """Get OpenAI API key for Whisper transcription."""
    return get_secret("openai-api-key")


def get_anthropic_api_key() -> str:
    """Get Anthropic API key for Claude."""
    return get_secret("anthropic-api-key")


# For backwards compatibility and direct env var access in Cloud Run
class SecretSettings:
    """
    Settings class that loads from Secret Manager.
    Use this instead of loading from .env files.
    """
    
    @property
    def DB_PASSWORD(self) -> str:
        return get_db_password()
    
    @property
    def OPENAI_API_KEY(self) -> str:
        return get_openai_api_key()
    
    @property
    def ANTHROPIC_API_KEY(self) -> str:
        return get_anthropic_api_key()


# Global instance
secrets = SecretSettings()
